package com.hefshine.MavenTesting;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Mavendemo {
	@Test
	public void mvn1() {
		
		System.setProperty("webdriver.chrome.Driver","C:\\Users\\jijau\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
	//	WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.saucedemo.com");
		driver.manage().window().maximize();
	}
	

}
